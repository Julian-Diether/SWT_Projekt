// © 2016 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html

u"sa\u0127\u0127a";
u'\u6587';
u"\U000219F2";
u"\u039C\u03C5\u03C3\u03C4\u03AE\u03C1\u03B9\u03BF";

 u"sa\u0127\u0127a";
 u'\u6587'; u"\U000219F2";

"\x20\xCC\x81";
"\xCC\x88\x20";
"\x73\x61\xC4\xA7\xC4\xA7\x61";
"\xE6\x96\x87";
"\xF0\xA1\xA7\xB2";
"\x73\x61\xC4\xA7\xC4\xA7\x61";

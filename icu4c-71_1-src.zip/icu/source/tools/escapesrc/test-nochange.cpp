// © 2016 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html

// This is a source file with no changes needed in it.
// In fact, the only non-ASCII character is the comment line at top.
